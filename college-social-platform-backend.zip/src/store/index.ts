import { create } from 'zustand';
import type { User, Post, Club, Event, Notification, TabType, UserRole } from '../types';

// Helper to generate IDs
const genId = () => Math.random().toString(36).substring(2, 12);

// Default avatars by initial
const getAvatar = (name: string) => {
  const colors = ['3b82f6', 'd946ef', 'f59e0b', '10b981', 'ef4444', '8b5cf6', '06b6d4'];
  const color = colors[name.charCodeAt(0) % colors.length];
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=${color}&color=fff&size=128&bold=true`;
};

// Seed data
const seedUsers: User[] = [
  {
    id: 'admin-1',
    username: 'campus_admin',
    displayName: 'Campus Admin',
    email: 'admin@campus.edu',
    password: 'admin123',
    role: 'admin',
    avatar: getAvatar('Campus Admin'),
    bio: 'Official CampusConnect administrator. Keeping our community informed and connected.',
    department: 'Administration',
    joinedClubs: [],
    followers: ['user-1', 'user-2', 'user-3', 'user-4'],
    following: [],
    createdAt: '2024-01-01T00:00:00Z',
    verified: true,
  },
  {
    id: 'user-1',
    username: 'alex_dev',
    displayName: 'Alex Rivera',
    email: 'alex@campus.edu',
    password: 'pass123',
    role: 'club_leader',
    avatar: getAvatar('Alex Rivera'),
    bio: '💻 CS Major | President of CodeCraft Club | Building the future one line at a time',
    department: 'Computer Science',
    year: 3,
    joinedClubs: ['club-1', 'club-3'],
    followers: ['user-2', 'user-3', 'admin-1'],
    following: ['user-2', 'admin-1', 'user-3'],
    createdAt: '2024-02-15T00:00:00Z',
    verified: true,
  },
  {
    id: 'user-2',
    username: 'maya_arts',
    displayName: 'Maya Chen',
    email: 'maya@campus.edu',
    password: 'pass123',
    role: 'club_leader',
    avatar: getAvatar('Maya Chen'),
    bio: '🎨 Fine Arts & Design | Leading the Creative Collective | Art is life',
    department: 'Fine Arts',
    year: 2,
    joinedClubs: ['club-2', 'club-4'],
    followers: ['user-1', 'user-4'],
    following: ['user-1', 'admin-1'],
    createdAt: '2024-03-01T00:00:00Z',
    verified: true,
  },
  {
    id: 'user-3',
    username: 'jordan_ball',
    displayName: 'Jordan Williams',
    email: 'jordan@campus.edu',
    password: 'pass123',
    role: 'student',
    avatar: getAvatar('Jordan Williams'),
    bio: '🏀 Basketball team captain | Sports Science major | Never stop grinding',
    department: 'Sports Science',
    year: 4,
    joinedClubs: ['club-5', 'club-1'],
    followers: ['user-1', 'user-4'],
    following: ['user-1', 'user-2', 'admin-1'],
    createdAt: '2024-03-15T00:00:00Z',
    verified: false,
  },
  {
    id: 'user-4',
    username: 'priya_science',
    displayName: 'Priya Sharma',
    email: 'priya@campus.edu',
    password: 'pass123',
    role: 'student',
    avatar: getAvatar('Priya Sharma'),
    bio: '🔬 Physics nerd | Quantum Computing enthusiast | Tea > Coffee',
    department: 'Physics',
    year: 2,
    joinedClubs: ['club-1', 'club-3', 'club-6'],
    followers: ['user-3'],
    following: ['user-1', 'user-2', 'user-3', 'admin-1'],
    createdAt: '2024-04-01T00:00:00Z',
    verified: false,
  },
];

const seedClubs: Club[] = [
  {
    id: 'club-1',
    name: 'CodeCraft',
    description: 'The premier coding club. We build apps, compete in hackathons, and learn cutting-edge tech together.',
    category: 'tech',
    leaderId: 'user-1',
    members: ['user-1', 'user-3', 'user-4'],
    avatar: getAvatar('CodeCraft'),
    coverImage: '',
    createdAt: '2024-02-20T00:00:00Z',
    isOfficial: true,
    events: ['event-1', 'event-4'],
  },
  {
    id: 'club-2',
    name: 'Creative Collective',
    description: 'Express yourself through art, design, and creativity. All skill levels welcome!',
    category: 'arts',
    leaderId: 'user-2',
    members: ['user-2'],
    avatar: getAvatar('Creative Collective'),
    coverImage: '',
    createdAt: '2024-03-05T00:00:00Z',
    isOfficial: true,
    events: ['event-2'],
  },
  {
    id: 'club-3',
    name: 'Robotics Society',
    description: 'Design, build, and program robots. Participate in national competitions.',
    category: 'tech',
    leaderId: 'user-1',
    members: ['user-1', 'user-4'],
    avatar: getAvatar('Robotics Society'),
    coverImage: '',
    createdAt: '2024-03-10T00:00:00Z',
    isOfficial: true,
    events: ['event-5'],
  },
  {
    id: 'club-4',
    name: 'Drama Society',
    description: 'Theatre, improv, and performance arts. Annual plays and workshops.',
    category: 'cultural',
    leaderId: 'user-2',
    members: ['user-2'],
    avatar: getAvatar('Drama Society'),
    coverImage: '',
    createdAt: '2024-03-20T00:00:00Z',
    isOfficial: false,
    events: ['event-3'],
  },
  {
    id: 'club-5',
    name: 'Sports Council',
    description: 'Organizing inter-college tournaments, fitness events, and sports meetups.',
    category: 'sports',
    leaderId: 'user-3',
    members: ['user-3'],
    avatar: getAvatar('Sports Council'),
    coverImage: '',
    createdAt: '2024-04-01T00:00:00Z',
    isOfficial: true,
    events: ['event-6'],
  },
  {
    id: 'club-6',
    name: 'Science Forum',
    description: 'Discussions, experiments, and exploration of cutting-edge science topics.',
    category: 'academic',
    leaderId: 'user-4',
    members: ['user-4'],
    avatar: getAvatar('Science Forum'),
    coverImage: '',
    createdAt: '2024-04-15T00:00:00Z',
    isOfficial: false,
    events: [],
  },
];

const seedEvents: Event[] = [
  {
    id: 'event-1',
    title: 'Hackathon 2025',
    description: '24-hour hackathon. Build something amazing! Food and prizes provided.',
    clubId: 'club-1',
    date: '2025-11-15T09:00:00Z',
    location: 'Engineering Hall, Room 301',
    attendees: ['user-1', 'user-3', 'user-4'],
    maxCapacity: 100,
    createdAt: '2025-09-01T00:00:00Z',
  },
  {
    id: 'event-2',
    title: 'Art Exhibition: Perspectives',
    description: 'Student art exhibition showcasing diverse perspectives through various media.',
    clubId: 'club-2',
    date: '2025-11-20T14:00:00Z',
    location: 'Student Gallery, Arts Building',
    attendees: ['user-2'],
    maxCapacity: 200,
    createdAt: '2025-09-15T00:00:00Z',
  },
  {
    id: 'event-3',
    title: 'Shakespeare Night',
    description: 'An evening of Shakespeare\'s greatest scenes performed by Drama Society members.',
    clubId: 'club-4',
    date: '2025-12-01T18:00:00Z',
    location: 'Auditorium',
    attendees: ['user-2'],
    maxCapacity: 300,
    createdAt: '2025-09-20T00:00:00Z',
  },
  {
    id: 'event-4',
    title: 'Workshop: Intro to React',
    description: 'Beginner-friendly React workshop. Bring your laptop!',
    clubId: 'club-1',
    date: '2025-11-08T15:00:00Z',
    location: 'CS Lab 2',
    attendees: ['user-1', 'user-4'],
    maxCapacity: 40,
    createdAt: '2025-10-01T00:00:00Z',
  },
  {
    id: 'event-5',
    title: 'Robot Battle Championship',
    description: 'Annual robot battle competition. Build your bot and compete!',
    clubId: 'club-3',
    date: '2025-12-10T10:00:00Z',
    location: 'Engineering Workshop',
    attendees: ['user-1', 'user-4'],
    maxCapacity: 50,
    createdAt: '2025-10-15T00:00:00Z',
  },
  {
    id: 'event-6',
    title: 'Inter-College Basketball Tournament',
    description: 'Annual basketball tournament. Come support our team!',
    clubId: 'club-5',
    date: '2025-11-25T08:00:00Z',
    location: 'Sports Complex',
    attendees: ['user-3'],
    maxCapacity: 500,
    createdAt: '2025-10-20T00:00:00Z',
  },
];

const now = new Date();
const h = (hoursAgo: number) => new Date(now.getTime() - hoursAgo * 3600000).toISOString();

const seedPosts: Post[] = [
  {
    id: 'post-1',
    authorId: 'admin-1',
    content: '📢 Important: Mid-semester exams schedule has been released. Check the academic portal for your personalized timetable. All the best! #Exams #MidSem',
    likes: ['user-1', 'user-2', 'user-3', 'user-4'],
    reposts: ['user-1'],
    replies: ['post-2'],
    isAnnouncement: true,
    isPinned: true,
    tags: ['exams', 'midsem'],
    createdAt: h(2),
  },
  {
    id: 'post-2',
    authorId: 'user-4',
    content: 'Thanks for the heads up! Time to start studying 📚',
    likes: ['user-1', 'user-3'],
    reposts: [],
    replies: [],
    parentId: 'post-1',
    isAnnouncement: false,
    isPinned: false,
    tags: [],
    createdAt: h(1.5),
  },
  {
    id: 'post-3',
    authorId: 'user-1',
    content: '🚀 Just wrapped up an amazing CodeCraft session! We built a real-time chat app using WebSockets. Next week: intro to machine learning. Don\'t miss it!\n\n#CodeCraft #WebDev #Programming',
    likes: ['user-3', 'user-4', 'admin-1'],
    reposts: ['user-4'],
    replies: ['post-4'],
    isAnnouncement: false,
    isPinned: false,
    clubId: 'club-1',
    tags: ['codecraft', 'webdev', 'programming'],
    createdAt: h(5),
  },
  {
    id: 'post-4',
    authorId: 'user-3',
    content: 'That session was fire 🔥 Can\'t wait for the ML workshop!',
    likes: ['user-1'],
    reposts: [],
    replies: [],
    parentId: 'post-3',
    isAnnouncement: false,
    isPinned: false,
    tags: [],
    createdAt: h(4),
  },
  {
    id: 'post-5',
    authorId: 'user-2',
    content: '🎨 Calling all artists! Our annual art exhibition "Perspectives" is coming up on Nov 20th. Submit your work by Nov 10th. All mediums welcome!\n\nDM me for details. #Art #Exhibition #CreativeCollective',
    likes: ['user-1', 'user-4'],
    reposts: ['admin-1'],
    replies: [],
    isAnnouncement: false,
    isPinned: false,
    clubId: 'club-2',
    tags: ['art', 'exhibition', 'creativecollective'],
    createdAt: h(8),
  },
  {
    id: 'post-6',
    authorId: 'user-3',
    content: '🏀 Game day tomorrow! We\'re up against State University in the semi-finals. Come support the team at the Sports Complex, 4 PM. Let\'s go! 💪\n\n#Basketball #GameDay #GoTeam',
    likes: ['user-1', 'user-2', 'user-4', 'admin-1'],
    reposts: ['user-1', 'user-2'],
    replies: ['post-7'],
    isAnnouncement: false,
    isPinned: false,
    clubId: 'club-5',
    tags: ['basketball', 'gameday', 'goteam'],
    createdAt: h(12),
  },
  {
    id: 'post-7',
    authorId: 'user-1',
    content: 'Let\'s gooo! 🔥 I\'ll be there with the whole CodeCraft crew cheering!',
    likes: ['user-3'],
    reposts: [],
    replies: [],
    parentId: 'post-6',
    isAnnouncement: false,
    isPinned: false,
    tags: [],
    createdAt: h(11),
  },
  {
    id: 'post-8',
    authorId: 'admin-1',
    content: '🏛️ The new student lounge in Block C is now open! Features: study pods, gaming area, coffee bar, and high-speed WiFi. Open 8 AM - 10 PM daily.\n\n#CampusLife #NewFacility',
    likes: ['user-1', 'user-2', 'user-3', 'user-4'],
    reposts: ['user-2', 'user-3'],
    replies: [],
    isAnnouncement: true,
    isPinned: false,
    tags: ['campuslife', 'newfacility'],
    createdAt: h(24),
  },
  {
    id: 'post-9',
    authorId: 'user-4',
    content: '🔬 Mind = blown! Just attended a guest lecture on quantum entanglement by Dr. Patel. The implications for quantum computing are insane. If anyone wants my notes, reply here!\n\n#Physics #QuantumComputing #ScienceForum',
    likes: ['user-1', 'admin-1'],
    reposts: [],
    replies: [],
    isAnnouncement: false,
    isPinned: false,
    clubId: 'club-6',
    tags: ['physics', 'quantumcomputing', 'scienceforum'],
    createdAt: h(16),
  },
  {
    id: 'post-10',
    authorId: 'user-1',
    content: 'Hot take: Python is overrated for beginners. Start with JavaScript — you can build anything from websites to APIs to mobile apps. Fight me 😤\n\n#Programming #HotTake',
    likes: ['user-3'],
    reposts: [],
    replies: [],
    isAnnouncement: false,
    isPinned: false,
    tags: ['programming', 'hottake'],
    createdAt: h(30),
  },
];

const seedNotifications: Notification[] = [
  {
    id: 'notif-1',
    userId: 'user-1',
    type: 'like',
    fromUserId: 'user-3',
    postId: 'post-3',
    message: 'Jordan Williams liked your post',
    read: false,
    createdAt: h(4),
  },
  {
    id: 'notif-2',
    userId: 'user-1',
    type: 'reply',
    fromUserId: 'user-3',
    postId: 'post-4',
    message: 'Jordan Williams replied to your post',
    read: false,
    createdAt: h(4),
  },
  {
    id: 'notif-3',
    userId: 'user-1',
    type: 'announcement',
    postId: 'post-1',
    message: 'New campus announcement: Mid-semester exams schedule released',
    read: true,
    createdAt: h(2),
  },
];

interface AppState {
  // Auth
  currentUser: User | null;
  isAuthenticated: boolean;
  authError: string | null;
  
  // Data
  users: User[];
  posts: Post[];
  clubs: Club[];
  events: Event[];
  notifications: Notification[];
  
  // UI
  activeTab: TabType;
  selectedPost: string | null;
  selectedClub: string | null;
  selectedProfile: string | null;
  composeOpen: boolean;
  searchQuery: string;
  
  // Auth actions
  login: (email: string, password: string) => boolean;
  register: (data: { username: string; displayName: string; email: string; password: string; role: UserRole; department: string; year?: number }) => boolean;
  logout: () => void;
  
  // Post actions
  createPost: (content: string, options?: { parentId?: string; clubId?: string; isAnnouncement?: boolean; tags?: string[] }) => void;
  likePost: (postId: string) => void;
  repostPost: (postId: string) => void;
  deletePost: (postId: string) => void;
  pinPost: (postId: string) => void;
  
  // Club actions
  joinClub: (clubId: string) => void;
  leaveClub: (clubId: string) => void;
  createClub: (data: { name: string; description: string; category: string }) => void;
  
  // Event actions
  attendEvent: (eventId: string) => void;
  createEvent: (data: { title: string; description: string; clubId: string; date: string; location: string; maxCapacity?: number }) => void;
  
  // User actions
  followUser: (userId: string) => void;
  updateProfile: (data: Partial<User>) => void;
  
  // Notification actions
  markNotificationRead: (notifId: string) => void;
  markAllNotificationsRead: () => void;
  
  // UI actions
  setActiveTab: (tab: TabType) => void;
  setSelectedPost: (id: string | null) => void;
  setSelectedClub: (id: string | null) => void;
  setSelectedProfile: (id: string | null) => void;
  setComposeOpen: (open: boolean) => void;
  setSearchQuery: (q: string) => void;
  
  // Helpers
  getUserById: (id: string) => User | undefined;
  getPostsByUser: (userId: string) => Post[];
  getPostReplies: (postId: string) => Post[];
  getClubsByUser: (userId: string) => Club[];
  getEventsByClub: (clubId: string) => Event[];
  getUnreadNotificationCount: () => number;
}

export const useStore = create<AppState>((set, get) => ({
  // Auth
  currentUser: null,
  isAuthenticated: false,
  authError: null,
  
  // Data
  users: seedUsers,
  posts: seedPosts,
  clubs: seedClubs,
  events: seedEvents,
  notifications: seedNotifications,
  
  // UI
  activeTab: 'home',
  selectedPost: null,
  selectedClub: null,
  selectedProfile: null,
  composeOpen: false,
  searchQuery: '',
  
  // Auth actions
  login: (email, password) => {
    const user = get().users.find(u => u.email === email && u.password === password);
    if (user) {
      set({ currentUser: user, isAuthenticated: true, authError: null });
      // Load notifications for this user
      return true;
    }
    set({ authError: 'Invalid email or password' });
    return false;
  },
  
  register: (data) => {
    const { users } = get();
    if (users.find(u => u.email === data.email)) {
      set({ authError: 'Email already registered' });
      return false;
    }
    if (users.find(u => u.username === data.username)) {
      set({ authError: 'Username already taken' });
      return false;
    }
    const newUser: User = {
      id: `user-${genId()}`,
      username: data.username,
      displayName: data.displayName,
      email: data.email,
      password: data.password,
      role: data.role || 'student',
      avatar: getAvatar(data.displayName),
      bio: '',
      department: data.department,
      year: data.year,
      joinedClubs: [],
      followers: [],
      following: [],
      createdAt: new Date().toISOString(),
      verified: false,
    };
    set({ users: [...users, newUser], currentUser: newUser, isAuthenticated: true, authError: null });
    return true;
  },
  
  logout: () => set({ currentUser: null, isAuthenticated: false, activeTab: 'home', selectedPost: null, selectedClub: null, selectedProfile: null }),
  
  // Post actions
  createPost: (content, options = {}) => {
    const { currentUser, posts } = get();
    if (!currentUser) return;
    
    const tagMatches = content.match(/#(\w+)/g);
    const tags = options.tags || (tagMatches ? tagMatches.map(t => t.slice(1).toLowerCase()) : []);
    
    const newPost: Post = {
      id: `post-${genId()}`,
      authorId: currentUser.id,
      content,
      likes: [],
      reposts: [],
      replies: [],
      parentId: options.parentId,
      isAnnouncement: options.isAnnouncement || false,
      isPinned: false,
      clubId: options.clubId,
      tags,
      createdAt: new Date().toISOString(),
    };
    
    let updatedPosts = [newPost, ...posts];
    
    // If it's a reply, add to parent's replies
    if (options.parentId) {
      updatedPosts = updatedPosts.map(p => 
        p.id === options.parentId 
          ? { ...p, replies: [...p.replies, newPost.id] }
          : p
      );
    }
    
    set({ posts: updatedPosts, composeOpen: false });
  },
  
  likePost: (postId) => {
    const { currentUser, posts } = get();
    if (!currentUser) return;
    set({
      posts: posts.map(p => {
        if (p.id !== postId) return p;
        const liked = p.likes.includes(currentUser.id);
        return { ...p, likes: liked ? p.likes.filter(id => id !== currentUser.id) : [...p.likes, currentUser.id] };
      }),
    });
  },
  
  repostPost: (postId) => {
    const { currentUser, posts } = get();
    if (!currentUser) return;
    set({
      posts: posts.map(p => {
        if (p.id !== postId) return p;
        const reposted = p.reposts.includes(currentUser.id);
        return { ...p, reposts: reposted ? p.reposts.filter(id => id !== currentUser.id) : [...p.reposts, currentUser.id] };
      }),
    });
  },
  
  deletePost: (postId) => {
    const { posts } = get();
    set({ posts: posts.filter(p => p.id !== postId) });
  },
  
  pinPost: (postId) => {
    const { posts } = get();
    set({
      posts: posts.map(p => p.id === postId ? { ...p, isPinned: !p.isPinned } : p),
    });
  },
  
  // Club actions
  joinClub: (clubId) => {
    const { currentUser, clubs, users } = get();
    if (!currentUser) return;
    set({
      clubs: clubs.map(c => c.id === clubId ? { ...c, members: [...c.members, currentUser.id] } : c),
      users: users.map(u => u.id === currentUser.id ? { ...u, joinedClubs: [...u.joinedClubs, clubId] } : u),
      currentUser: { ...currentUser, joinedClubs: [...currentUser.joinedClubs, clubId] },
    });
  },
  
  leaveClub: (clubId) => {
    const { currentUser, clubs, users } = get();
    if (!currentUser) return;
    set({
      clubs: clubs.map(c => c.id === clubId ? { ...c, members: c.members.filter(id => id !== currentUser.id) } : c),
      users: users.map(u => u.id === currentUser.id ? { ...u, joinedClubs: u.joinedClubs.filter(id => id !== clubId) } : u),
      currentUser: { ...currentUser, joinedClubs: currentUser.joinedClubs.filter(id => id !== clubId) },
    });
  },
  
  createClub: (data) => {
    const { currentUser, clubs } = get();
    if (!currentUser) return;
    const newClub: Club = {
      id: `club-${genId()}`,
      name: data.name,
      description: data.description,
      category: data.category as any,
      leaderId: currentUser.id,
      members: [currentUser.id],
      avatar: getAvatar(data.name),
      coverImage: '',
      createdAt: new Date().toISOString(),
      isOfficial: false,
      events: [],
    };
    set({ clubs: [...clubs, newClub] });
  },
  
  // Event actions
  attendEvent: (eventId) => {
    const { currentUser, events } = get();
    if (!currentUser) return;
    set({
      events: events.map(e => {
        if (e.id !== eventId) return e;
        const attending = e.attendees.includes(currentUser.id);
        return { ...e, attendees: attending ? e.attendees.filter(id => id !== currentUser.id) : [...e.attendees, currentUser.id] };
      }),
    });
  },
  
  createEvent: (data) => {
    const { events, clubs } = get();
    const newEvent: Event = {
      id: `event-${genId()}`,
      ...data,
      attendees: [],
      createdAt: new Date().toISOString(),
    };
    set({
      events: [...events, newEvent],
      clubs: clubs.map(c => c.id === data.clubId ? { ...c, events: [...c.events, newEvent.id] } : c),
    });
  },
  
  // User actions
  followUser: (userId) => {
    const { currentUser, users } = get();
    if (!currentUser || currentUser.id === userId) return;
    const isFollowing = currentUser.following.includes(userId);
    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return { ...u, following: isFollowing ? u.following.filter(id => id !== userId) : [...u.following, userId] };
      }
      if (u.id === userId) {
        return { ...u, followers: isFollowing ? u.followers.filter(id => id !== currentUser.id) : [...u.followers, currentUser.id] };
      }
      return u;
    });
    const updatedCurrentUser = updatedUsers.find(u => u.id === currentUser.id)!;
    set({ users: updatedUsers, currentUser: updatedCurrentUser });
  },
  
  updateProfile: (data) => {
    const { currentUser, users } = get();
    if (!currentUser) return;
    const updated = { ...currentUser, ...data };
    set({
      currentUser: updated,
      users: users.map(u => u.id === currentUser.id ? updated : u),
    });
  },
  
  // Notification actions
  markNotificationRead: (notifId) => {
    set({ notifications: get().notifications.map(n => n.id === notifId ? { ...n, read: true } : n) });
  },
  markAllNotificationsRead: () => {
    const { currentUser, notifications } = get();
    if (!currentUser) return;
    set({ notifications: notifications.map(n => n.userId === currentUser.id ? { ...n, read: true } : n) });
  },
  
  // UI actions
  setActiveTab: (tab) => set({ activeTab: tab, selectedPost: null, selectedClub: null, selectedProfile: null }),
  setSelectedPost: (id) => set({ selectedPost: id }),
  setSelectedClub: (id) => set({ selectedClub: id }),
  setSelectedProfile: (id) => set({ selectedProfile: id }),
  setComposeOpen: (open) => set({ composeOpen: open }),
  setSearchQuery: (q) => set({ searchQuery: q }),
  
  // Helpers
  getUserById: (id) => get().users.find(u => u.id === id),
  getPostsByUser: (userId) => get().posts.filter(p => p.authorId === userId && !p.parentId),
  getPostReplies: (postId) => get().posts.filter(p => p.parentId === postId),
  getClubsByUser: (userId) => get().clubs.filter(c => c.members.includes(userId)),
  getEventsByClub: (clubId) => get().events.filter(e => e.clubId === clubId),
  getUnreadNotificationCount: () => {
    const { currentUser, notifications } = get();
    if (!currentUser) return 0;
    return notifications.filter(n => n.userId === currentUser.id && !n.read).length;
  },
}));
